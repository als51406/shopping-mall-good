Thanks for downloading Continuous font!
Designed by Beomdolee (https://beomdolee.com/continuous-eng)

✔ Free for personal and commercial use
📩 For updates and new font releases, visit: https://beomdolee.com/continuous-eng